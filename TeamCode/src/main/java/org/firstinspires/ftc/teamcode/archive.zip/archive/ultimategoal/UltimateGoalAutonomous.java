/*
Copyright 2021 FIRST Tech Challenge Team FTC

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
package org.firstinspires.ftc.teamcode.ultimategoal;

import com.qualcomm.hardware.bosch.BNO055IMU;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Acceleration;
import java.text.DecimalFormat;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This file contains an example of an iterative (Non-Linear) "OpMode".
 * An OpMode is a 'program' that runs in either the autonomous or the teleop period of an FTC match.
 * The names of OpModes appear on the menu of the FTC Driver Station.
 * When an selection is made from the menu, the corresponding OpMode
 * class is instantiated on the Robot Controller and executed.
 *
 * Remove a @Disabled the on the next line or two (if present) to add this opmode to the Driver Station OpMode list,
 * or add a @Disabled annotation to prevent this OpMode from being added to the Driver Station
 */
@Autonomous
@Disabled
public class UltimateGoalAutonomous extends OpMode {
    /* Declare OpMode members. */
    private DcMotor FrontLauncher = null;
    private DcMotor RearLauncher = null;
    private DcMotor TankDrive = null;
    private CRServo leftIntake = null;
    private CRServo rightIntake = null;
    private ColorSensor bottomColor = null;
    private DistanceSensor rightDist = null;
    private MecanumAutonomousAdvanced mecanum = new MecanumAutonomousAdvanced();
    // private MecanumDriveAdvanced mecanum = new MecanumDriveAdvanced();
    
    public DecimalFormat format = new DecimalFormat("##.00");
    private BNO055IMU imu;

    double TheLiTheory = 0;
    int autoState = 0;
    
    public Orientation angles;
    public Acceleration gravity;


    @Override
    public void init() {
        gyroInit();
        FrontLauncher = hardwareMap.get(DcMotor.class, "FrontLauncher");
        RearLauncher = hardwareMap.get(DcMotor.class, "RearLauncher");
        TankDrive = hardwareMap.get(DcMotor.class, "TankDrive");
        TankDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        TankDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftIntake = hardwareMap.get(CRServo.class, "leftIntake");
        rightIntake = hardwareMap.get(CRServo.class, "rightIntake");
        bottomColor = hardwareMap.get(ColorSensor.class, "bottomColor");
        rightDist = hardwareMap.get(DistanceSensor.class, "vertRightDist");
        
        mecanum.init(gamepad1, hardwareMap);
        
        Rev2mDistanceSensor sensorTimeOfFlight = (Rev2mDistanceSensor)rightDist;

        telemetry.addData("Status", "Initialized");
    }

    /*
     * Code to run REPEATEDLY after the driver hits INIT, but before they hit PLAY
     */
    @Override
    public void init_loop() {

    }

    /*
     * Code to run ONCE when the driver hits PLAY
     */
    @Override
    public void start() {

    }

    /*
     * Code to run REPEATEDLY after the driver hits PLAY but before they hit STOP
     */
    @Override
    public void loop() {
        gyroLoop();
        TheLiTheory = (bottomColor.green() + bottomColor.red() + bottomColor.green())/3;
        
        telemetry.addData("TheLiTheorem", TheLiTheory);
        telemetry.addData("autoState", autoState);
        telemetry.addData("EncPos", mecanum.getFrontRight());
        telemetry.addData("Tank", TankDrive.getCurrentPosition());
        
        mecanum.go();
        
        switch(autoState) {
            case 0:
                // StafeLeft
                    double distance = rightDist.getDistance(DistanceUnit.CM);
                    telemetry.addData("rightVertDist", distance);
                    mecanum.setSlide(-1);
                    stayOnTarget(-2, 2);
                    if (distance > 115) {
                        mecanum.setSlide(0);
                        autoState++; 
                    }
                break;
            
            case 1:
                // DriveFwd
                    mecanum.setFwd(-1);
                    stayOnTarget(-2, 2);
                    if (TheLiTheory > 150) {
                        mecanum.setFwd(0);
                        autoState++;
                    }
                    
                break;
            
            case 2:
                // BackUp 
                    mecanum.setFwd(0.5f);
                    stayOnTarget(-1, 1);
                    if (mecanum.getFrontRight() * -1 < 9000) {
                        mecanum.setFwd(0);
                        autoState++;
                    }
    
                break;
            
            case 3:
                // Turn to target
                FrontLauncher.setPower(-0.90f);
                RearLauncher.setPower(-0.90f);
                stayOnTarget(14, 12);
                
                if (angles.firstAngle > 12) {
                    TankDrive.setPower(-1);
                    autoState++;
                }
                
                break;
                
            case 4:
                // LAUNCH
                stayOnTarget(17, 15);
                if (TankDrive.getCurrentPosition() * -1 > 1000) {
                    autoState++;
                }
                
                break;
            
            case 5: 
                // Turn
                stayOnTarget(19, 17);
                if (TankDrive.getCurrentPosition() * -1 > 7000) {
                    TankDrive.setPower(0);
                    FrontLauncher.setPower(0);
                    RearLauncher.setPower(0);
                    autoState++; 
                }
                
                break;
            
            case 6: 
                // Lineup 
                stayOnTarget(-2, 2);
                mecanum.setFwd(-0.8f);
                if (TheLiTheory > 150) {
                    mecanum.setFwd(0);
                    autoState++;
                }
                break;
            
            case 7:
                stayOnTarget(-1, 1);
                break;
        }

    }

    /*
     * Code to run ONCE after the driver hits STOP
     */
    @Override
    public void stop() {

    }
    
    private void stayOnTarget(int topAngle, int bottomAngle) {
        if(angles.firstAngle > topAngle){
            mecanum.setRotate(0.25f);
        } else if(angles.firstAngle < bottomAngle) {
            mecanum.setRotate(-0.25f); 
        } else if(topAngle > angles.firstAngle && angles.firstAngle > bottomAngle) {
            mecanum.setRotate(0.0f); 
        }
    }
    
    private void spinAround(int topAngle, int bottomAngle) {
        if(angles.firstAngle > topAngle){
            mecanum.setRotate(0.65f);
        } else if(angles.firstAngle < bottomAngle) {
            mecanum.setRotate(-0.65f); 
        } else if(topAngle + 1 > angles.firstAngle && angles.firstAngle > bottomAngle - 1) {
            mecanum.setRotate(0.0f); 
        }
    }
    
    private void gyroInit() {
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();

        parameters.mode = BNO055IMU.SensorMode.IMU;
        parameters.angleUnit = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.loggingEnabled = false;

        imu.initialize(parameters);
    }
    
    private void gyroLoop() {
        angles = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        telemetry.addData("HEADING", angles.firstAngle);
    }



}
