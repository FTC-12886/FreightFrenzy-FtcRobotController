// Simplified Mecanum Control Code
// Darius Bieganski, 2020
// Key Features
    // None

package org.firstinspires.ftc.teamcode.ultimategoal;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx; 
import com.qualcomm.robotcore.hardware.Gamepad; 

public class MecDrive {

    //private HardwareMap hardwareMap;
    private Gamepad gamepad1;
    private DcMotorEx[] wheel_motors; // [4]
    private double[] target_power; 
    private int i; // for loop index for going over wheel motors
    
    public void init(Gamepad gamepad, HardwareMap hardwareMap) {

        // Wheel order:
        // 0 - front left
        // 1 - front right
        // 2 - rear left
        // 3 - rear right
        gamepad1 = gamepad; 

        target_power = new double[4];

        wheel_motors = new DcMotorEx[4];
        wheel_motors[0] = (DcMotorEx) hardwareMap.get(DcMotor.class, "FrontLeft");
        wheel_motors[1] = (DcMotorEx) hardwareMap.get(DcMotor.class, "FrontRight");
        wheel_motors[2] = (DcMotorEx) hardwareMap.get(DcMotor.class, "RearLeft");
        wheel_motors[3] = (DcMotorEx) hardwareMap.get(DcMotor.class, "RearRight");

        for (i=0; i<4; i++) {
            wheel_motors[i].setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            wheel_motors[i].setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        }
        wheel_motors[0].setDirection(DcMotor.Direction.REVERSE);
        wheel_motors[1].setDirection(DcMotor.Direction.FORWARD);
        wheel_motors[2].setDirection(DcMotor.Direction.REVERSE);
        wheel_motors[3].setDirection(DcMotor.Direction.FORWARD);
    }

    public void testDrive(double power) {
        wheel_motors[0].setPower(power);
        wheel_motors[1].setPower(power);
        wheel_motors[2].setPower(power);
        wheel_motors[3].setPower(power);
    }

    public void drive() {
        double r = Math.hypot(joystick_side(), joystick_fwd());
        double robotAngle = 0;
        double rightX = joystick_rotate(); 

        target_power[0] = r * Math.cos(robotAngle) + rightX; // FrontLeft 
        target_power[1] = r * Math.sin(robotAngle) - rightX; // FrontRight
        target_power[2] = (r * Math.sin(robotAngle) + rightX)/3; // RearLeft
        target_power[3] = r * Math.cos(robotAngle) - rightX; // RearRight

        for (i=0; i<4; i++) {
            wheel_motors[i].setPower(target_power[i]);
        }
    }

    // double r = Math.hypot(gamepad1.left_stick_x, gamepad1.left_stick_y);
    // double robotAngle = Math.atan2(gamepad1.left_stick_y, gamepad1.left_stick_x) - Math.PI / 4;
    // double rightX = gamepad1.right_stick_x;
    // final double v1 = r * Math.cos(robotAngle) + rightX;
    // final double v2 = r * Math.sin(robotAngle) - rightX;
    // final double v3 = r * Math.sin(robotAngle) + rightX;
    // final double v4 = r * Math.cos(robotAngle) - rightX;

    // leftFront.setPower(v1);
    // rightFront.setPower(v2);
    // leftRear.setPower(v3)
    // rightRear.setPower(v4);

    float joystick_fwd() {
        return gamepad1.left_stick_y; 
    }

    float joystick_side() {
        return gamepad1.left_stick_x; 
    }

    float joystick_rotate() {
        return gamepad1.right_stick_x; 
    }

    
}
